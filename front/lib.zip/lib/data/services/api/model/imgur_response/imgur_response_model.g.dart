// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'imgur_response_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ImgurResponseModelImpl _$$ImgurResponseModelImplFromJson(
        Map<String, dynamic> json) =>
    _$ImgurResponseModelImpl(
      link: json['link'] as String,
    );

Map<String, dynamic> _$$ImgurResponseModelImplToJson(
        _$ImgurResponseModelImpl instance) =>
    <String, dynamic>{
      'link': instance.link,
    };
