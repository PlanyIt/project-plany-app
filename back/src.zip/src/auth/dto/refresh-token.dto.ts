export class RefreshTokenDto {
  refreshToken: string;
}
